# Wakely

Wakely is a Flutter alarm app built for people who can't be trusted to snooze responsibly. Instead of a swipe-to-dismiss button, Wakely makes you complete a short mental task — a chess puzzle, a math problem, or a memory challenge — before it will let the alarm stop ringing.

## Features

- **Mission-based alarms** — solve a puzzle to dismiss the alarm, so your brain is actually awake before you go back to sleep on your phone
- **Sleep tracking** — uses motion and ambient sound to estimate sleep quality overnight and produce a nightly sleep score
- **Morning report** — a post-wake summary combining sleep quality, wake-task performance, and local weather
- **Reliable alarm scheduling** — built on exact alarms and full-screen intents so alarms fire even under battery optimization

## Tech stack

- **Flutter / Dart**
- [`alarm`](https://pub.dev/packages/alarm) for reliable scheduled alarms across iOS and Android
- `sensors_plus` + `noise_meter` + `record` for on-device sleep tracking
- `shared_preferences` for local persistence of sleep history and settings
- `fl_chart` for sleep and performance visualizations

## Getting started

```bash
flutter pub get
flutter run
```

### Running tests

```bash
flutter test
```

## Platforms

Wakely targets iOS and Android as primary platforms, with Flutter's desktop/web scaffolding present but not actively maintained as user-facing targets.
