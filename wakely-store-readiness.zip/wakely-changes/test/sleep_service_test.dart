import 'package:flutter_test/flutter_test.dart';
import 'package:wakely/services/sleep_service.dart';

/// These tests cover SleepSession and AudioEvent — the data models that
/// persist a user's sleep history to disk as JSON via SharedPreferences.
///
/// This is the highest-value place to have tests today: SleepService's
/// tracking/scoring logic depends on static state and hardware plugins
/// (accelerometer, microphone) that would need dependency injection to
/// test in isolation. The serialization logic below, however, is pure
/// and is exactly what silently corrupts stored sleep history if a future
/// change to a field name or type isn't backward compatible.
void main() {
  group('AudioEvent', () {
    test('round-trips through toJson/fromJson', () {
      final original = AudioEvent(
        time: DateTime(2026, 3, 14, 23, 45),
        type: '🌙 Sleep Moment',
        durationSeconds: 25,
        file: '/data/sleep_audio/clip1.m4a',
        isSaved: true,
      );

      final restored = AudioEvent.fromJson(original.toJson());

      expect(restored.time, original.time);
      expect(restored.type, original.type);
      expect(restored.durationSeconds, original.durationSeconds);
      expect(restored.file, original.file);
      expect(restored.isSaved, original.isSaved);
    });

    test('fromJson fills in defaults for missing optional fields', () {
      final json = {
        'time': DateTime(2026, 1, 1).toIso8601String(),
        'file': '/data/sleep_audio/clip2.m4a',
      };

      final event = AudioEvent.fromJson(json);

      expect(event.type, '🌙 Sleep Moment');
      expect(event.durationSeconds, 0);
      expect(event.isSaved, false);
    });
  });

  group('SleepSession', () {
    test('round-trips through toJson/fromJson, including nested audioEvents', () {
      final start = DateTime(2026, 3, 14, 23, 0);
      final end = DateTime(2026, 3, 15, 7, 0);

      final original = SleepSession(
        startTime: start,
        endTime: end,
        score: 78,
        confidence: 'High',
        totalMovementEvents: 12,
        soundActivityEvents: 3,
        additionalMoments: 1,
        wakePerformanceScore: 15,
        audioEvents: [
          AudioEvent(
            time: start.add(const Duration(hours: 2)),
            type: '🌙 Sleep Moment',
            durationSeconds: 25,
            file: '/data/sleep_audio/clip1.m4a',
          ),
        ],
      );

      final restored = SleepSession.fromJson(original.toJson());

      expect(restored.startTime, start);
      expect(restored.endTime, end);
      expect(restored.score, 78);
      expect(restored.confidence, 'High');
      expect(restored.totalMovementEvents, 12);
      expect(restored.soundActivityEvents, 3);
      expect(restored.additionalMoments, 1);
      expect(restored.wakePerformanceScore, 15);
      expect(restored.audioEvents.length, 1);
      expect(restored.audioEvents.first.file, '/data/sleep_audio/clip1.m4a');
    });

    test('duration getter reflects the gap between start and end time', () {
      final session = SleepSession(
        startTime: DateTime(2026, 3, 14, 23, 0),
        endTime: DateTime(2026, 3, 15, 6, 30),
        score: 80,
        confidence: 'High',
        totalMovementEvents: 0,
        soundActivityEvents: 0,
      );

      expect(session.duration, const Duration(hours: 7, minutes: 30));
    });

    test('fromJson falls back to legacy totalNoiseEvents key when soundActivityEvents is absent', () {
      final json = {
        'startTime': DateTime(2026, 1, 1).toIso8601String(),
        'endTime': DateTime(2026, 1, 1, 8).toIso8601String(),
        'score': 70,
        'confidence': 'Medium',
        'totalMovementEvents': 5,
        'totalNoiseEvents': 9,
      };

      final session = SleepSession.fromJson(json);

      expect(session.soundActivityEvents, 9);
    });

    test('fromJson applies sensible defaults when optional fields are missing', () {
      final json = {
        'startTime': DateTime(2026, 1, 1).toIso8601String(),
        'endTime': DateTime(2026, 1, 1, 8).toIso8601String(),
      };

      final session = SleepSession.fromJson(json);

      expect(session.score, 80);
      expect(session.confidence, 'Medium');
      expect(session.totalMovementEvents, 0);
      expect(session.soundActivityEvents, 0);
      expect(session.additionalMoments, 0);
      expect(session.wakePerformanceScore, isNull);
      expect(session.audioEvents, isEmpty);
    });

    test('copyWith only overrides the fields that are passed', () {
      final original = SleepSession(
        startTime: DateTime(2026, 1, 1),
        endTime: DateTime(2026, 1, 1, 8),
        score: 70,
        confidence: 'Medium',
        totalMovementEvents: 4,
        soundActivityEvents: 2,
      );

      final updated = original.copyWith(score: 85, wakePerformanceScore: 15);

      // Overridden fields change.
      expect(updated.score, 85);
      expect(updated.wakePerformanceScore, 15);

      // Everything else stays the same.
      expect(updated.confidence, original.confidence);
      expect(updated.startTime, original.startTime);
      expect(updated.endTime, original.endTime);
      expect(updated.totalMovementEvents, original.totalMovementEvents);
      expect(updated.soundActivityEvents, original.soundActivityEvents);
    });
  });
}
