# How to apply these changes to your local clone

## 1. Code changes (`wakely-changes/`)
Copy these into your local `chessAlarm` clone, overwriting the existing files at the same relative paths:

- `android/app/build.gradle.kts` — new applicationId/namespace + release signing config
- `android/app/src/main/kotlin/com/yashnimkar/wakely/MainActivity.kt` — moved from the old `com/example/chess_alarm` path
- `README.md`
- `test/sleep_service_test.dart`

Then **delete the old package directory** so it's not left behind:
```bash
rm -rf android/app/src/main/kotlin/com/example
```

Commit these as normal — none of them are secrets.

## 2. Keystore + key.properties (`keystore-KEEP-PRIVATE-DO-NOT-COMMIT/`)
Place these two files here in your local clone:
```
android/app/upload-keystore.jks
android/key.properties
```
`android/.gitignore` already excludes both `key.properties` and `*.jks`, so `git status` should show nothing for them. **Double-check that before your first commit** — if either shows up as "untracked" ready to be added, stop and don't commit it.

**Back up `upload-keystore.jks` and the password somewhere durable** (password manager + a second location, e.g. a private cloud drive). If you lose this keystore, you will not be able to publish updates to this app on Google Play ever again under the same listing — Google cannot recover or reset it for you.

## 3. Verify before building
```bash
flutter pub get
flutter test        # confirm the new SleepService tests pass
flutter analyze      # confirm no errors from the rename/gradle changes
flutter build appbundle --release   # should now sign with your upload key, not debug
```

I wasn't able to run `flutter test`/`flutter analyze` myself — this sandbox doesn't have the Flutter SDK installed — so please run these locally before you consider it submission-ready.
