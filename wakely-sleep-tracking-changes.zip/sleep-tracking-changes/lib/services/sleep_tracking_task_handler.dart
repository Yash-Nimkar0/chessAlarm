// SKELETON — NOT WIRED IN YET.
//
// This maps out the Android foreground-service refactor needed for sleep
// tracking to survive the phone being locked overnight. I could not verify
// this compiles: this sandbox has no Flutter SDK and no access to pub.dev,
// so the flutter_foreground_task API below is based on its documented
// pattern as of early/mid-2026 but is NOT guaranteed to match whatever
// version `flutter pub add flutter_foreground_task` resolves for you.
//
// Before trusting this on a real device:
//   1. Run `flutter pub add flutter_foreground_task` and open the installed
//      package's README/example (in your pub cache or on pub.dev) to check
//      this matches its current API — class names, method signatures, and
//      the ForegroundTaskOptions/AndroidNotificationOptions constructors
//      have changed across versions.
//   2. This is the kind of change I'd strongly recommend testing with
//      Claude Code locally, where you can actually run `flutter build` and
//      `flutter run --release` against a real device, rather than trusting
//      an unverified diff for something going to app stores.
//
// What this is supposed to do:
//   - Move the accelerometer + noise-meter listening (currently in
//     SleepService.startTracking()) into a TaskHandler that keeps running
//     in a foreground service, independent of whether the Flutter UI
//     isolate is alive.
//   - Communicate detected movement/sound events back to the main isolate
//     via the plugin's SendPort/ReceivePort mechanism (or, more simply,
//     have the handler itself read/write the same SharedPreferences
//     checkpoint that SleepService._saveCheckpoint() already writes, so
//     the two don't need to talk to each other directly).
//   - Show a persistent low-priority notification ("Wakely is tracking
//     your sleep...") for as long as the service runs, which is required
//     by Android to keep a foreground service alive.
//
// Recommended approach: rather than duplicating SleepService's stream
// logic here, consider having this handler own the accelerometer/noise
// subscriptions directly and write straight to the checkpoint key that
// SleepService already reads on recovery — that keeps a single source of
// truth for the data format instead of two divergent implementations.

// import 'package:flutter_foreground_task/flutter_foreground_task.dart';
//
// @pragma('vm:entry-point')
// void startSleepTrackingCallback() {
//   FlutterForegroundTask.setTaskHandler(SleepTrackingTaskHandler());
// }
//
// class SleepTrackingTaskHandler extends TaskHandler {
//   // TODO: move accelerometer/noise stream subscriptions here, mirroring
//   // the logic in SleepService.startTracking() / _onNoiseReading().
//
//   @override
//   Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
//     // TODO: initialize sensor streams
//   }
//
//   @override
//   void onRepeatEvent(DateTime timestamp) {
//     // TODO: periodic checkpoint write, mirroring SleepService._saveCheckpoint()
//   }
//
//   @override
//   Future<void> onDestroy(DateTime timestamp) async {
//     // TODO: clean up stream subscriptions
//   }
// }
//
// Future<void> startForegroundSleepTracking() async {
//   FlutterForegroundTask.init(
//     androidNotificationOptions: AndroidNotificationOptions(
//       channelId: 'sleep_tracking',
//       channelName: 'Sleep Tracking',
//       channelDescription: 'Wakely is tracking your sleep overnight.',
//       onlyAlertOnce: true,
//     ),
//     iosNotificationOptions: const IOSNotificationOptions(
//       showNotification: false,
//       playSound: false,
//     ),
//     foregroundTaskOptions: ForegroundTaskOptions(
//       eventAction: ForegroundTaskEventAction.repeat(300000), // 5 min, matches checkpoint interval
//       autoRunOnBoot: false,
//       allowWakeLock: true,
//     ),
//   );
//
//   if (await FlutterForegroundTask.isRunningService) {
//     await FlutterForegroundTask.restartService();
//   } else {
//     await FlutterForegroundTask.startService(
//       serviceId: 100,
//       notificationTitle: 'Wakely',
//       notificationText: 'Tracking your sleep...',
//       callback: startSleepTrackingCallback,
//     );
//   }
// }
//
// Future<void> stopForegroundSleepTracking() async {
//   await FlutterForegroundTask.stopService();
// }
