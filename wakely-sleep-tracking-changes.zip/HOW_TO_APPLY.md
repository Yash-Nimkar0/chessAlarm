# Sleep tracking architecture changes — how to apply

Copy each file into your local clone at the same relative path, overwriting the existing one.

## Done and reasonably confident in
- `lib/services/sleep_service.dart` — fixes the midnight-crossing consistency bug, adds
  5-minute checkpointing during tracking, adds `recoverOrphanedSession()` to recover a
  session if the process is killed before `stopTracking()` runs, and adds a silent
  looping-audio keep-alive for iOS background execution.
- `lib/main.dart` — calls `SleepService.recoverOrphanedSession()` on startup.
- `test/sleep_service_test.dart` — new tests, including regression tests for the
  consistency fix.
- `assets/silence.wav` + `pubspec.yaml` — 1-second silent WAV asset registered for the
  iOS keep-alive loop.

Run `flutter test` to confirm the new tests pass, and manually test the recovery path by
force-killing the app mid-tracking and reopening it.

## Needs your verification before you trust it — Android foreground service
`lib/services/sleep_tracking_task_handler.dart` is a **skeleton, not wired in**. I don't
have Flutter tooling or pub.dev access in my sandbox, so I could not verify the
`flutter_foreground_task` API calls against whatever version actually resolves for you —
this package's API has changed across recent versions.

Steps to finish this part:
1. `flutter pub add flutter_foreground_task` (this replaces the placeholder version I put
   in `pubspec.yaml` with whatever the tool resolves — check that against what's in the
   pubspec already, they should match).
2. Open the installed package's README (in your local pub cache, or on pub.dev) and
   compare it against the commented-out code in `sleep_tracking_task_handler.dart`. Fix
   any mismatched method/class names.
3. Move the accelerometer/noise-meter listening logic out of
   `SleepService.startTracking()` and into the `TaskHandler`, so it runs in the
   foreground service rather than the main isolate. The simplest path: have the handler
   write directly to the same `sleep_tracking_checkpoint` SharedPreferences key that
   `SleepService._saveCheckpoint()` already writes, so `recoverOrphanedSession()` keeps
   working without changes.
4. Test on a real Android device with the screen off and the app fully backgrounded for
   at least 30+ minutes before considering this done — this is exactly the kind of thing
   that looks fine in a quick test and fails at 3am on a real phone.

Honestly, I'd do this specific piece with Claude Code locally rather than trust an
unverified diff from me — it can actually run `flutter build`, install on a device, and
iterate against real errors instead of guesswork.

## Also note
- The Android manifest changes (`FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_DATA_SYNC`
  permissions) are in already, but if the `flutter_foreground_task` README asks for a
  different service type or a manual `<service>` declaration, add that too.
- Once tracking, actually works reliably backgrounded, revisit whether `WakelockPlus` is
  still needed at all in `sleep_screen.dart` — with a proper foreground service, forcing
  the screen to stay on all night is no longer necessary and should be removed for
  battery life.
